#include "functions.h"
#include <iostream>
#include <vector>
#include <thread>

using namespace std;

void example1()
{
	cout << "\n~~~ Test Set 1 ~~~" << endl;
	// TODO: Uncomment when ready to test
	/*
	int a = 3;
	int b = 4;
	int c = a + b;
	cout << "The sum of " << a << " and " << b << " is: " << c << endl;
	*/
}

void example2()
{
	cout << "\n~~~ Test Set 2 ~~~" << endl;
	// TODO: you'll have to add code here to test other things
}
