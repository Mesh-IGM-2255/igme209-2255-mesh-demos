#pragma once

void example1();

void example2();